import React, { useContext, useState  } from 'react';
import Form from 'react-bootstrap/Form';
import FloatingLabel from 'react-bootstrap/FloatingLabel';
import Button from 'react-bootstrap/Button';

import './cylinder.css';
import Checkboxkey from '../checkboxkey/Checkboxkey';
import CheckboxKeyContext from '../CheckboxKeyContext';
import { cylinderTypes } from './data';


function Cylinder({ nextKey, onRemove }) {
  const { checkboxKeyCount, increaseCheckboxKeyCount } = useContext(CheckboxKeyContext);

  const renderCheckboxkeys = () => {
    const elements = [];
    for (let i = 0; i < checkboxKeyCount; i++) {
      elements.push(<Checkboxkey key={i} schluesselnummer={i+1}/>);
    }
    return elements;
  };

  const [cylinderType, setCylinderType] = useState(cylinderTypes[0].value);

  const [validationMessageAussen, setValidationMessageAussen] = useState('');
  const [validationMessageInnen, setValidationMessageInnen] = useState('');

  const handleCylinderTypeChange = (event) => {
    setCylinderType(event.target.value);
  };

  const validateNumberAussen = (event) => {
    const number = parseInt(event.target.value, 10);

    if (number < 25 || number > 80) {
      setValidationMessageAussen('Bitte geben Sie eine Zahl zwischen 25 und 80 ein.');
    } else {
      setValidationMessageAussen('');
    }
  };

  const validateNumberInnen = (event) => {
    const number = parseInt(event.target.value, 10);

    if (number < 25 || number > 80) {
      setValidationMessageInnen('Bitte geben Sie eine Zahl zwischen 25 und 80 ein.');
    } else {
      setValidationMessageInnen('');
    }
  };

  const handleRemove = () => {
    onRemove(nextKey);
  };

  return (
    <tr id={`cylinder-${nextKey}`}> 

      <td>{nextKey}</td>

      <td>
        <Form.Control
          className="door-descr"
          defaultValue={`Tür-${nextKey}`}
          aria-label="Small"
          aria-describedby="inputGroup-sizing-sm"
        />
      </td>

      <td>
        <Form.Select 
          aria-label="Default select example"
          value={cylinderType}
          onChange={handleCylinderTypeChange}
        >
          {cylinderTypes.map((type) => (
            <option key={type.value} value={type.value}>
              {type.label}
            </option>
          ))}
        </Form.Select>
      </td>
      
      <td className="min-max">
      {cylinderType !== "4" && cylinderType !== "5" && cylinderType !== "6" && (
        <span id="cyl-min">
          <FloatingLabel controlId="floatingInput" label="außen" className="mb-3">
            <Form.Control
              type="number"
              placeholder="25"
              defaultValue={0}
              className="aussen-number"
              aria-label="Small"
              aria-describedby="inputGroup-sizing-sm"
              onChange={validateNumberAussen}
            />
            {validationMessageAussen && <div className="validation-message">{validationMessageAussen}</div>}
          </FloatingLabel>
        </span>
        )}
        {cylinderType !== "3" && cylinderType !== "4" && cylinderType !== "5" && cylinderType !== "6" && (
          <span id="cyl-max">
            <FloatingLabel controlId="floatingInput2" label="innen" className="mb-3">
              <Form.Control
                type="number"
                placeholder="25"
                defaultValue={0}
                className="innen-number"
                aria-label="Small"
                aria-describedby="inputGroup-sizing-sm"
                onChange={validateNumberInnen} 
              />
              {validationMessageInnen && <div className="validation-message">{validationMessageInnen}</div>}
            </FloatingLabel>
          </span>
        )}
      </td>
     

      <td>
        <Form.Control
          type="number"
          placeholder="1"
          defaultValue={1}
          className="door-number"
          aria-label="Small"
          aria-describedby="inputGroup-sizing-sm"
        />
      </td>

       {renderCheckboxkeys()}

      <td className="option-buttons">
        <Button 
          variant="danger" 
          id="remove-cylinder"
          onClick={handleRemove}
        >Cylinder löschen</Button>
      </td>

    </tr>
  );
}

export default Cylinder;