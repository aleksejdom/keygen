export const cylinderTypes = [
  { value: 1, label: 'Doppelzylinder' },
  { value: 2, label: 'Knaufzylinder' },
  { value: 3, label: 'Halbzylinder' },
  { value: 4, label: 'Vorhangschloss' },
  { value: 5, label: 'Briefkastenzylinder' },
  { value: 6, label: 'Außenzylinder' },
];

 