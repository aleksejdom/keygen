import React, { useState, useEffect, useMemo } from 'react';
import './cylinders.css';
import Table from 'react-bootstrap/Table';
import Button from 'react-bootstrap/Button';

import Cylinder from '../cylinder/Cylinder';
import Keys from '../keys/Keys';
import CheckboxKeyContext from '../CheckboxKeyContext';
 

function Cylinders() {
  const [cylinders, setCylinders] = useState([]);
  const [nextKey, setNextKey] = useState(1);
  const [schluesselnummer, setSchluesselnummer] = useState(1);
  const [checkboxKeyCount, setCheckboxKeyCount] = useState(1);
 

  useEffect(() => {
    const newCylinders = [
      <Cylinder
        key={nextKey}
        nextKey={nextKey}
        onRemove={handleRemoveCylinder} 
      />,
    ];
    setCylinders(newCylinders);
    setNextKey(nextKey + 1);
  }, []);

  const handleAddCylinder = () => {
    const newCylinders = [
      ...cylinders,
      <Cylinder
        key={nextKey}
        nextKey={nextKey}
        onRemove={handleRemoveCylinder} 
      />,
    ];
    setCylinders(newCylinders);
    setNextKey(nextKey + 1);
  };

  const handleRemoveCylinder = (cylinderId) => {
    setCylinders((prevCylinders) =>
      prevCylinders.filter((cylinder) => cylinder.key !== cylinderId.toString())
    );
  };

  const handleAddKeys = () => {
    setSchluesselnummer(schluesselnummer + 1);
    setCheckboxKeyCount(checkboxKeyCount + 1); 
  };
  const handleRemoveKeys = () => {
    if (schluesselnummer > 0 && checkboxKeyCount > 0) {
      setSchluesselnummer(schluesselnummer - 1);
      setCheckboxKeyCount(checkboxKeyCount - 1); 
    } else {
      console.log('Die Anzahl der Schlüssel kann nicht unter 0 gehen.');
    }
  };
 
  const value = useMemo(() => ({ checkboxKeyCount, increaseCheckboxKeyCount: handleAddKeys }), [checkboxKeyCount]);

  return (
    <CheckboxKeyContext.Provider value={value}>
      <div className="cylinders-block">
        <h1 className="headline">Schließanlagen Konfigurator für Alexander Domovec</h1>
        <Table striped bordered hover>
          <thead>
            <tr className="table-header">
              <th>Pos</th>
              <th>Türbezeichnung</th>
              <th>Zylindertyp</th>
              <th>Zylinderlänge in mm</th>
              <th>Stück</th> 
              {[...Array(schluesselnummer)].map((_, index) => (
                <th className="schluessel" key={`schluessel-${index + 1}`}>
                  <Keys key={index + 1} schluesselnummer={index + 1} />
                </th>
              ))}
              <th>Options</th>
            </tr>
          </thead>
          <tbody>{cylinders}</tbody>
          <tfoot>
            <tr>
              <td colSpan={5 + schluesselnummer}>
                <div className="options">
                  <Button
                    variant="primary"
                    id="add-cylinder"
                    onClick={handleAddCylinder}
                  >
                    Cylinder hinzufügen
                  </Button>
                  <Button
                    variant="secondary"
                    id="add-key"
                    onClick={handleAddKeys}
                  >
                    Schlüssel hinzufügen
                  </Button>
                  <Button
                    variant="danger"
                    id="remove-key"
                    onClick={handleRemoveKeys}
                  >
                    Schlüssel löschen
                  </Button>
                </div>
              </td>
            </tr>
          </tfoot>
        </Table>
      </div> 
    </CheckboxKeyContext.Provider>
  );
}

export default Cylinders;